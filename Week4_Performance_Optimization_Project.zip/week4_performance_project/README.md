# Week 4 — Frontend Performance Optimization Challenge

PixelPeak Studio is a lightweight responsive portfolio/agency landing page demonstrating practical frontend performance techniques.

## Files
- `index.html`: semantic content and navigation; hero image preload and deferred script
- `styles.css`: responsive styling with system font stack and no CSS framework
- `script.js`: small mobile-navigation behavior
- `assets/`: local SVG illustrations
- `REPORT.docx`: internship task report

## Run
Extract the ZIP and open `index.html` in a browser. No build tools or external JavaScript libraries are required. All artwork is local SVG; the page does not depend on remote image APIs.

## Performance techniques
- Minimal HTML, CSS, and JavaScript; no framework or third-party runtime.
- Local vector SVG assets to keep illustrations crisp and lightweight.
- Preload the above-the-fold hero artwork and set `fetchpriority="high"`.
- Load below-the-fold project illustrations with `loading="lazy"` and `decoding="async"`.
- Explicit image width and height attributes reserve layout space and help reduce layout shift.
- JavaScript is loaded with `defer`; no blocking scripts in the document head.
- System font stack avoids waiting for a remote font download.
- Responsive CSS and a small script keep the page adaptable without large dependencies.

## Suggested evaluation
Run Lighthouse (mobile and desktop) or PageSpeed Insights after serving the project over a local/static web server. Check Performance, Accessibility, Best Practices, and SEO. Compare before/after metrics such as LCP, CLS, and total page weight. For production hosting, configure Brotli/Gzip compression, long-lived caching for versioned static assets, and HTTP/2 or HTTP/3 at the server/CDN.
