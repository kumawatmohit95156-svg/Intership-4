const menuButton = document.querySelector('.menu-button');
const nav = document.querySelector('#nav-links');

menuButton.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', String(isOpen));
  menuButton.querySelector('.menu-text').textContent = isOpen ? 'Close' : 'Menu';
});

nav.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => {
    nav.classList.remove('open');
    menuButton.setAttribute('aria-expanded', 'false');
    menuButton.querySelector('.menu-text').textContent = 'Menu';
  });
});

document.querySelector('#year').textContent = new Date().getFullYear();
